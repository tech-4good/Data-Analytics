import pandas as pd
import unicodedata
import re
import boto3
from io import StringIO, BytesIO
import json
import os

def clean_df(df: pd.DataFrame) -> pd.DataFrame:
    def clean_cell(cell):
        if pd.isnull(cell):
            return cell
        if isinstance(cell, str):
            # Converte para maiúsculas
            s = cell.upper()
            
            # Remove as acentuações
            s = unicodedata.normalize('NFD', s)
            s = ''.join(c for c in s if unicodedata.category(c) != 'Mn')
            
            # Remove os caracteres especiais (mantém pontos)
            s = re.sub(r"[^A-Z0-9 \.,%()\-]", '', s)
            
            # Normaliza os espaços
            s = re.sub(r'\s+', ' ', s).strip()
            return s
        return cell

    # Aplica a função de limpeza a todo o DataFrame
    return df.map(lambda c: clean_cell(c) if not pd.isnull(c) else c)

def get_bucket_names():
    """Obtém os nomes dos buckets raw e trusted"""
    try:
        s3 = boto3.client('s3')
        response = s3.list_buckets()
        raw_bucket = None
        trusted_bucket = None
        
        for bucket in response['Buckets']:
            if 't4g-ra' in bucket['Name']:
                raw_bucket = bucket['Name']
            elif 't4g-tr' in bucket['Name']:
                trusted_bucket = bucket['Name']
                
        if not raw_bucket or not trusted_bucket:
            raise Exception("Buckets não encontrados")
            
        return raw_bucket, trusted_bucket
    except Exception as e:
        print(f"Erro ao obter nomes dos buckets: {str(e)}")
        raise

def process_files():
    """Processa os arquivos do bucket raw e salva no bucket trusted"""
    try:
        # Obtém nomes dos buckets
        raw_bucket, trusted_bucket = get_bucket_names()
        
        # Configuração do cliente S3
        s3 = boto3.client('s3')
        
        # Lista arquivos no diretório Arquivos_Brutos do bucket raw
        response = s3.list_objects_v2(
            Bucket=raw_bucket,
            Prefix='Arquivos_Brutos/'
        )
        
        if 'Contents' not in response:
            return {
                'statusCode': 200,
                'body': json.dumps('Nenhum arquivo encontrado no bucket raw')
            }
            
        processed_files = []
        errors = []
        
        # Processa cada arquivo
        for obj in response['Contents']:
            try:
                # Pula se for o próprio diretório
                if obj['Key'].endswith('/'):
                    continue
                    
                print(f"Processando arquivo: {obj['Key']}")
                
                # Lê o arquivo do S3
                response = s3.get_object(Bucket=raw_bucket, Key=obj['Key'])
                
                # Determina o tipo de arquivo pela extensão
                file_extension = obj['Key'].lower().split('.')[-1]
                
                if file_extension == 'xlsx':
                    # Para arquivos Excel
                    excel_data = BytesIO(response['Body'].read())
                    df = pd.read_excel(excel_data, dtype=str)
                elif file_extension == 'csv':
                    # Para arquivos CSV, tenta diferentes codificações
                    try:
                        df = pd.read_csv(response['Body'], sep=';', dtype=str, encoding='utf-8')
                    except UnicodeDecodeError:
                        # Se falhar com utf-8, tenta com latin-1
                        df = pd.read_csv(response['Body'], sep=';', dtype=str, encoding='latin-1')
                else:
                    raise ValueError(f"Formato de arquivo não suportado: {file_extension}")
                
                # Aplica a limpeza
                df_cleaned = clean_df(df)
                
                # Prepara o arquivo de saída
                csv_buffer = StringIO()
                df_cleaned.to_csv(csv_buffer, index=False, encoding='utf-8-sig', sep=';')
                
                # Define o novo nome do arquivo no bucket trusted
                original_name = obj['Key'].split('/')[-1]
                new_name = original_name.rsplit('.', 1)[0] + '_tratado.csv'
                trusted_key = f'Arquivos_Tratados/{new_name}'
                
                # Salva no bucket trusted
                s3.put_object(
                    Bucket=trusted_bucket,
                    Key=trusted_key,
                    Body=csv_buffer.getvalue().encode('utf-8-sig')
                )
                
                processed_files.append(obj['Key'])
                print(f"Arquivo processado e salvo: {trusted_key}")
                
            except Exception as e:
                error_msg = f"Erro ao processar arquivo {obj['Key']}: {str(e)}"
                errors.append(error_msg)
                print(error_msg)
                continue
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Processamento concluído',
                'processed_files': processed_files,
                'errors': errors
            })
        }
        
    except Exception as e:
        error_msg = f"Erro durante o processamento: {str(e)}"
        print(error_msg)
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': error_msg
            })
        }

def lambda_handler(event, context):
    """
    Função handler da Lambda
    :param event: Evento que trigou a Lambda (pode ser um evento do S3)
    :param context: Contexto de execução da Lambda
    """
    try:
        return process_files()
        
    except Exception as e:
        error_msg = f"Erro na execução da Lambda: {str(e)}"
        print(error_msg)
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': error_msg
            })
        }